/**
 *
 */

public class Arco extends Lado
{
  private Vertice extremoInicial;
  private Vertice extremoFinal;
  
  public Arco(String id, double peso, Vertice extremoInicial, Vertice extremoFinal) {
  }

  public Vertice getExtremoInicial() {
  }

  public Vertice getExtremoFinall() {
  }

  public String toString() {
  }
}