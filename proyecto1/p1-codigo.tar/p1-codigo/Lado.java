/**
 * 
 */

public abstract class Lado
{
  private String id;
  private double peso;

  public Lado(String id, double peso) {
  }

  public String getId() {
  }

  public double getPeso() {
  }

  public abstract String toString();

}